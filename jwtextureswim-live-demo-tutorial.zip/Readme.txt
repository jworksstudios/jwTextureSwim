Jerome "PJ" Williams
http://jworksstudios.com/plugins/jwtextureswim/
Git: https://github.com/jworksstudios/jwtextureswim
Live Demo: http://jworksstudios.github.io/jwtextureswim/
Twitter/@JWorksStudios

jwTextureSwim is a jQuery plugin to animate background textures. With minimal effort, you can spice up your static background textures. It works best with seamless textures, but with some creativity you can do marvelous things with a little code.

jwTextureSwim is built with the hope that people find it useful and if they find inspiration, can make improvements and pass it on. It is released under GNU usage liscense, so no warranty, it's free to use, tweak and share. So go nuts! 

I'd love to see how it is being used, so if you want to share and possibly even be added to the showcase, send me your link through JWorksStudios.com

Requirements:
jQuery - I used version 1.11.3 with this build, and it is included in the folder /js/
jwTextureSwim - Included in /js/